"""
Network analysis module.

Checks: TCP connections, hosts file, DNS cache.
"""

import os
import subprocess
import json
from datetime import datetime
from typing import Any, Dict, List

from .utils import new_report_file, run_ps, show_step, write_block


def analyze_network(date_limit: datetime, days: int,
                    root_dir: str, ts: str, win_name: str, win_build: int) -> Dict[str, Any]:
    """
    Analyze network connections, hosts file, and DNS cache.
    Returns data for dashboard.
    """
    show_step("NETWORK", "Connessioni TCP, hosts file, DNS cache...")

    out = os.path.join(root_dir, "17_Network", f"Network_{ts}.txt")
    new_report_file(out, "NETWORK [17] - CONNESSIONI E DNS", "",
                    win_name, win_build, days, date_limit)

    lines = []

    # --- TCP Connections ---
    tcp_conns = _get_tcp_connections()
    lines.append("  ---- CONNESSIONI TCP ATTIVE ----")
    for conn in tcp_conns:
        lines.append(
            f"  [TCP] {conn['local']}  ->  {conn['remote']}  |  PID: {conn['pid']}  |  {conn['process']}"
        )

    # --- Hosts file ---
    lines.append("")
    lines.append("  ---- FILE HOSTS (righe non-commento) ----")
    hosts_entries = _read_hosts_file()
    for h in hosts_entries:
        lines.append(f"  [HST] {h}")

    # --- DNS Cache ---
    lines.append("")
    lines.append("  ---- DNS CACHE ----")
    dns_cache = _get_dns_cache()
    for entry in dns_cache:
        lines.append(f"  [DNS] {entry['entry'].ljust(50)} -> {entry['data']}")

    write_block(out, lines)
    show_step("NETWORK", "Completato.", "green")

    return {
        "tcp_conns": tcp_conns,
        "hosts_entries": hosts_entries,
        "dns_cache": dns_cache[:50],  # First 50 for dashboard
    }


def _get_tcp_connections() -> List[Dict[str, str]]:
    """Get established TCP connections with process names."""
    conns = []
    try:
        ps_cmd = (
            "Get-NetTCPConnection -State Established | "
            "ForEach-Object { "
            "  $p = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue; "
            "  @{Local=\"$($_.LocalAddress):$($_.LocalPort)\"; "
            "    Remote=\"$($_.RemoteAddress):$($_.RemotePort)\"; "
            "    PID=$_.OwningProcess; "
            "    Process=if($p){$p.Name}else{'?'} } "
            "} | ConvertTo-Json -Compress"
        )
        result = run_ps(ps_cmd, timeout=15)
        if result.strip():
            data = json.loads(result.strip())
            if isinstance(data, dict):
                data = [data]
            conns = data
    except Exception:
        pass
    return conns


def _read_hosts_file() -> List[str]:
    """Read non-comment lines from the hosts file."""
    entries = []
    hosts_path = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                              "System32", "drivers", "etc", "hosts")
    try:
        with open(hosts_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    entries.append(line)
    except Exception:
        entries.append("[--] File hosts non trovato.")
    return entries


def _get_dns_cache() -> List[Dict[str, str]]:
    """Get DNS client cache entries."""
    entries = []
    try:
        result = run_ps("Get-DnsClientCache | ConvertTo-Json -Compress", timeout=15)
        if result.strip():
            data = json.loads(result.strip())
            if isinstance(data, dict):
                data = [data]
            for item in data:
                entries.append({
                    "entry": item.get("Entry", ""),
                    "data": item.get("Data", ""),
                    "type": item.get("Type", ""),
                })
    except Exception:
        pass
    return entries
