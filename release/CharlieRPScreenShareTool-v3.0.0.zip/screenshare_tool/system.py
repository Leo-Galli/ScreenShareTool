"""
System information module.

Detects: Virtual Machine, VPN/Tunnel adapters, hardware info (CPU, RAM, GPU),
disk usage, and Windows version details.
"""

import os
import subprocess
from datetime import datetime
from typing import Any, Dict, List, Optional

from .config import VM_MFR_RE, VM_MODEL_RE, VM_VIDEO_RE, VPN_RE
from .utils import new_report_file, run_ps, show_step, write_block


def get_system_info() -> Dict[str, Any]:
    """
    Gather comprehensive system information.
    Returns a dict with all hardware/VM/VPN data.
    """
    info = {
        "is_vm": False,
        "vm_info": "Hardware fisico",
        "vpn_active": [],
        "cpu": "",
        "ram_gb": 0.0,
        "gpu": "",
        "model": "",
        "manufacturer": "",
        "os_name": "",
        "os_build": 0,
        "disks": [],
    }

    # OS version
    try:
        import platform
        info["os_name"] = platform.platform()
        info["os_build"] = int(platform.version().split(".")[-1]) if platform.version().split(".")[-1].isdigit() else 0
    except Exception:
        pass

    # PowerShell-based hardware query
    try:
        ps_cmd = (
            "$cs = Get-CimInstance Win32_ComputerSystem; "
            "$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1; "
            "$gpu = Get-CimInstance Win32_VideoController | Select-Object -First 1; "
            "@{"
            "  Model=$cs.Model; "
            "  Manufacturer=$cs.Manufacturer; "
            "  RAM=[math]::Round($cs.TotalPhysicalMemory/1GB,1); "
            "  CPU=$cpu.Name; "
            "  GPU=$gpu.Name; "
            "  VMModel=$cs.Model; "
            "  VMMfr=$cs.Manufacturer; "
            "  GPUName=$gpu.Name "
            "} | ConvertTo-Json -Compress"
        )
        result = run_ps(ps_cmd)
        if result.strip():
            import json
            data = json.loads(result.strip())
            info["model"] = data.get("Model", "")
            info["manufacturer"] = data.get("Manufacturer", "")
            info["ram_gb"] = float(data.get("RAM", 0))
            info["cpu"] = data.get("CPU", "")
            info["gpu"] = data.get("GPU", "")

            # VM detection
            model = data.get("VMModel", "")
            mfr = data.get("VMMfr", "")
            gpu_name = data.get("GPUName", "")
            if (VM_MODEL_RE.search(model) or VM_MFR_RE.search(mfr) or VM_VIDEO_RE.search(gpu_name)):
                info["is_vm"] = True
                info["vm_info"] = f"{mfr} - {model}"
    except Exception:
        pass

    # Disk usage
    try:
        ps_disk = (
            "Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match '^[A-Z]:\\\\$' } | "
            "ForEach-Object { "
            "  $used = [math]::Round($_.Used/1GB,1); "
            "  $total = [math]::Round(($_.Used+$_.Free)/1GB,1); "
            "  \"$($_.Name): ${used}GB usati / ${total}GB\" "
            "} | ConvertTo-Json -Compress"
        )
        result = run_ps(ps_disk)
        if result.strip():
            data = json.loads(result.strip())
            if isinstance(data, list):
                info["disks"] = data
            else:
                info["disks"] = [data]
    except Exception:
        pass

    # VPN detection
    try:
        ps_vpn = (
            "Get-NetAdapter | Where-Object { "
            "  $_.InterfaceDescription -match 'VPN|TAP|TUN|WireGuard|OpenVPN|ProtonVPN|NordVPN|ExpressVPN|Mullvad|Surfshark|Cisco|Fortinet|Pulse Secure' "
            "  -and $_.Status -eq 'Up' "
            "} | ForEach-Object { @{Name=$_.Name;Desc=$_.InterfaceDescription} } | ConvertTo-Json -Compress"
        )
        result = run_ps(ps_vpn)
        if result.strip():
            data = json.loads(result.strip())
            if isinstance(data, dict):
                data = [data]
            info["vpn_active"] = data
    except Exception:
        pass

    # Available drives
    info["drives"] = []
    try:
        ps_drives = (
            "Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match '^[A-Z]:\\\\$' } | "
            "ForEach-Object { $_.Root } | ConvertTo-Json -Compress"
        )
        result = run_ps(ps_drives)
        if result.strip():
            data = json.loads(result.strip())
            if isinstance(data, list):
                info["drives"] = data
            elif isinstance(data, str):
                info["drives"] = [data]
    except Exception:
        # Fallback: check common drive letters
        for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            if os.path.isdir(f"{letter}:\\"):
                info["drives"].append(f"{letter}:\\")

    return info


def analyze_system(date_limit: datetime, days: int,
                   root_dir: str, ts: str, win_name: str, win_build: int,
                   sys_info: Dict[str, Any]):
    """Write system info report (module 16)."""
    show_step("SYSTEM INFO", "VM detection, VPN, hardware...")

    out = os.path.join(root_dir, "16_SystemInfo", f"System_{ts}.txt")
    new_report_file(out, "SYSTEM INFO [16] - VM / VPN / HARDWARE", "",
                    win_name, win_build, days, date_limit)

    lines = []

    # VM
    lines.append("  ---- MACCHINA VIRTUALE ----")
    if sys_info["is_vm"]:
        lines.append("  [!!!] AMBIENTE VIRTUALE RILEVATO")
        lines.append(f"        Info       : {sys_info['vm_info']}")
        lines.append(f"        GPU        : {sys_info['gpu']}")
    else:
        lines.append("  [OK]  Hardware fisico.")
        lines.append(f"        Modello    : {sys_info['model']}")
        lines.append(f"        Produttore : {sys_info['manufacturer']}")

    # VPN
    lines.append("")
    lines.append("  ---- VPN ATTIVE ----")
    if sys_info["vpn_active"]:
        lines.append("  [!!!] VPN/TUNNEL ATTIVI:")
        for v in sys_info["vpn_active"]:
            lines.append(f"        - {v.get('Name', '?')} : {v.get('Desc', '?')}")
    else:
        lines.append("  [OK]  Nessuna VPN attiva.")

    # Hardware
    lines.append("")
    lines.append("  ---- HARDWARE ----")
    lines.append(f"  CPU : {sys_info['cpu']}")
    lines.append(f"  RAM : {sys_info['ram_gb']} GB")
    lines.append(f"  GPU : {sys_info['gpu']}")
    lines.append(f"  OS  : {win_name} (Build {win_build})")

    write_block(out, lines)
    show_step("SYSTEM INFO", "Completato.", "green")
